import java.util.ArrayList;

public class FilterManager {

    private ArrayList<Filter> filters;

    public FilterManager(){
        filters=new ArrayList<Filter>();
    }

   public void addFilter(Filter f){
        filters.add(f);
   }

    public String execute(String texto){
        String textoProcesado = texto;
        for(Filter f : filters){
            textoProcesado = f.execute(textoProcesado);
        }
        return textoProcesado;
    }



}
