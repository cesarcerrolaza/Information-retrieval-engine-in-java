public interface Filter {
    String execute(String texto);
}
