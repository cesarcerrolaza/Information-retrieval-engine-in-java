import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Recuperacion {

    public static HashMap<String,Tupla> cargarIndice(String docIndice) throws IOException {
        HashMap<String,Tupla> indice = new HashMap<>();
        System.out.println("Cargando indice...");
        String texto = new String(Files.readAllBytes(Paths.get(docIndice)));
        texto = texto.replaceAll("\\{", "" );
        texto = texto.replaceAll("}", "" );
        String[] indices = texto.split(" , ");

        for(String i:indices){
            HashMap<String,Double> docTFmap = new HashMap<>();
            String[] termIDF_docTF=i.split(" - ");

            String[] termIDF=termIDF_docTF[0].split("=");

            String[] docTF = termIDF_docTF[1].split(", ");

            for (String t: docTF) {
                String[] idPeso = t.split("=");
                docTFmap.put(idPeso[0], Double.parseDouble(idPeso[1]));
            }

            indice.put(termIDF[0], new Tupla(Double.parseDouble(termIDF[1]),docTFmap));

        }

        System.out.println("Indice cargado");
        return indice;
    }


    public static HashMap<String,Double> cargarLongitudDocumentos(String docPesoFile) throws IOException {
        HashMap<String,Double> docPeso =new HashMap<>();
        System.out.println("\nCargando longitudes...");

        String texto = new String(Files.readAllBytes(Paths.get(docPesoFile)));

        texto = texto.replaceAll("\\{", "" );
        texto = texto.replaceAll("}", "" );
        String[] docLongitudes = texto.split(", ");

        for(String docLongitud : docLongitudes)
        {
            String[] entry = docLongitud.split("=");
            docPeso.put(entry[0], Double.parseDouble(entry[1].trim()));
        }
        System.out.println("Longitudes cargadas");
        return docPeso;
    }


    public static void recupera(String consulta, String indiceInvertidoFile, String docPesoFile, int nResultados) throws IOException {

        String consultaProcesada = new Preprocessor().preprocess(consulta);


        ArrayList<String> lTerms = new ArrayList<String>(Arrays.asList(consultaProcesada.split(" ")));
        List<String> stopwords = Files.readAllLines(Paths.get("stopWords.txt"));
        lTerms.removeAll(stopwords);

        HashMap<String,Tupla> Indice = cargarIndice(indiceInvertidoFile);
        HashMap<String,Double> docLongitud = cargarLongitudDocumentos(docPesoFile);

        HashMap<String,Double> puntuacion=new HashMap<String,Double>();

        for(String doc : docLongitud.keySet()){
            puntuacion.put(doc,0.0);
        }

        TreeMap<String, Double> ordenado = new TreeMap<>();

        for(String termino : lTerms){
            double idf=0;
            HashMap<String, Double> docTf = new HashMap<>();

            if(Indice.containsKey(termino)){
                idf=Indice.get(termino).IDF();

                docTf=Indice.get(termino).get();
                for(String doc : puntuacion.keySet()) {
                    if (docTf.containsKey(doc)) {//compruebo que el termino esta en el documento actual
                        puntuacion.replace(doc, puntuacion.get(doc) + (idf * idf * docTf.get(doc) / docLongitud.get(doc)));
                    }
                }
            }
            Comparator<String> comparator = new ScoreComparator(puntuacion);
            ordenado = new TreeMap<String, Double>(comparator);
            ordenado.putAll(puntuacion);
        }

        System.out.println("\n\nMostrando Resultado");
        int i=0;

        for(String documento : ordenado.keySet()){
            if(i != nResultados && puntuacion.get(documento) > 0.0){
                System.out.println("------------------------------------------------------");
                System.out.println("Archivo: "+documento+" | Puntuacion: "+puntuacion.get(documento));

                i++;
            }
        }
    }


}
