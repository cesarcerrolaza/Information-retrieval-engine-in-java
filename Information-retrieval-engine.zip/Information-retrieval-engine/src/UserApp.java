import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class UserApp {

    public static void mostrarResultadoConsulta(List<File> docRanking){

    }

    public static void main(String[] args) throws IOException {

        String corpus = "C:\\Users\\Lenovo\\Desktop\\UNIVERSIDAD\\REC-INF\\PROYECTO\\corpus";

        Scanner keyboard = new Scanner(System.in);
        int op;

        List<File> docRanking = null;

        do{
            System.out.println("1-Calcular indice y longitud");
            System.out.println("2-Realizar consulta");
            System.out.println("0-Salir");

            System.out.println("Introduce una opcion:");

            op = keyboard.nextInt();
            switch (op){
                case 1 :
                    Indexer.Index(corpus, "Indice.txt", "Longitudes.txt");
                    break;
                case 2 :
                    if(new File("Indice.txt").exists() && new File("Longitudes.txt").exists()){
                        System.out.println("Introduce una consulta:");
                        String consulta = keyboard.nextLine();
                        consulta = keyboard.nextLine();

                        System.out.print("Introduce el numero de resultados que deseas: ");
                        int n= keyboard.nextInt();
                            Recuperacion.recupera(consulta, "Indice.txt", "Longitudes.txt",n);
                    }
                    else{
                        System.out.println("\nERROR, no existen los ficheros Indice.txt o Longitudes.txt, calcule indice y longitud primero\n");
                    }break;
                case 0 :
                    System.out.println("Saliendo...");
                    break;
                default :
                    System.out.println("ERROR, la opcion introducida no es valida. Intentelo de nuevo.");
            }
        }while(op != 0);
    }


}
