import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SpecialCharacterFilter implements Filter{
    String filtro;
    String replace;

    public SpecialCharacterFilter(String filtro, String replace) {
        this.filtro = filtro;
        this.replace = replace;
    }

    @Override
    public String execute(String texto) {
        Pattern pat = Pattern.compile(filtro);
        Matcher mat = pat.matcher(texto);
        return mat.replaceAll(replace);
    }
}
