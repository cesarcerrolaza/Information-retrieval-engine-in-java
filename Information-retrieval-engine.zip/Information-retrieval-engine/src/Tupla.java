import java.util.HashMap;

public class Tupla {
    double IDF = 0.0;
    HashMap<String,Double> docTf;

    public Tupla(){
        docTf = new HashMap<String,Double>();
    }

    public Tupla( String docID, Double tf){
        docTf = new HashMap<String,Double>();
        docTf.put(docID, tf);
    }

    public Tupla( double IDF, HashMap<String,Double> docTf){
        this.IDF=IDF;
        this.docTf = docTf;
    }

    public HashMap<String,Double> get(){ return docTf; }

    public void put(String docID, Double tf){ docTf.put(docID,tf); }

    public void IDF(double idf){ IDF = idf; }

    public double IDF(){ return IDF; }

    public void clear(){ docTf.clear(); }

    public String toString(){
        return IDF + " - " + docTf + " ";
    }
}
