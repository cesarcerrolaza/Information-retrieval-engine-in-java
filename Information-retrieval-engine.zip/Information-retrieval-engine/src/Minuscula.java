import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Minuscula implements Filter{
    @Override
    public String execute(String texto) {
        return texto.toLowerCase();
    }
}



