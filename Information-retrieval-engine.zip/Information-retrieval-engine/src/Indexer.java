import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Indexer {


    public static void Index(String filePath, String indiceInvertidoFile, String docPesoFile) throws IOException {
        File f = new File(filePath);
        ArrayList<String> lTerms;


        Preprocessor.buildFilter();

        HashMap<String, Double> termsFrecuency = new HashMap<>();
        double frecuency;

        HashMap<String,Tupla> indiceInvertido = new HashMap<>();
        HashMap<String,Double> docPeso = new HashMap<>();

        List<String> stopwords = Files.readAllLines(Paths.get("stopWords.txt"));

        int nFiles=0;
        String texto;
        String textoProcesado;
        for(File file : f.listFiles()) {

            texto = new String(Files.readAllBytes(Paths.get(file.getPath())));
            textoProcesado = new Preprocessor().preprocess(texto);

            lTerms = new ArrayList<String>(Arrays.asList(textoProcesado.split(" ")));
            lTerms.removeAll(stopwords);


            //tf paso 1
            termsFrecuency.clear();
            for (String termino : lTerms) {
                if (termsFrecuency.containsKey(termino)) {
                    frecuency = termsFrecuency.get(termino);
                    frecuency++;
                    termsFrecuency.put(termino, frecuency);
                } else termsFrecuency.put(termino, 1.0);
            }


            //tf paso 2
            for (Map.Entry<String, Double> entry : termsFrecuency.entrySet()) {
                Tupla parejaDocPeso = new Tupla();
                double tf = 1 + Math.log(entry.getValue()) / Math.log(2);

                if (indiceInvertido.containsKey(entry.getKey())) {
                    parejaDocPeso = indiceInvertido.get(entry.getKey());
                } else {
                    parejaDocPeso.clear();
                }
                parejaDocPeso.put(file.getName(), tf);
                indiceInvertido.put(entry.getKey(),parejaDocPeso);
            }

            docPeso.put(file.getName(),0.0);
            nFiles++;
        }

        for(String term : indiceInvertido.keySet()) {
            //Calculo del IDF
            indiceInvertido.get(term).IDF((Math.log((double) nFiles / indiceInvertido.get(term).get().size()))/Math.log(2));
            //Calculo de la longitud del documento
            for(String idDoc : indiceInvertido.get(term).get().keySet()){

                double peso = Math.pow(indiceInvertido.get(term).IDF() * indiceInvertido.get(term).get().get(idDoc),2); // peso = (termino.idf * termino.doc.tf)^2
                docPeso.replace(idDoc,peso + docPeso.get(idDoc)); // sumatorio de los pesos de los documentos

            }

        }

        for(String idDoc : docPeso.keySet()) {
            docPeso.replace(idDoc,Math.sqrt(docPeso.get(idDoc))); //raiz de los pesos de los documentos
        }

        guardarIndice(indiceInvertidoFile, indiceInvertido);
        guardarLongitud(docPesoFile, docPeso);

    }

    private static void guardarIndice(String indiceInvertidoFile, HashMap<String,Tupla> indiceInvertido) throws FileNotFoundException {
        System.out.println("Guardando indice...");
        PrintWriter f = new PrintWriter(indiceInvertidoFile);
        f.println(indiceInvertido);
        f.close();
        System.out.println("Indice guardado en" + indiceInvertidoFile);
    }

    private static void guardarLongitud(String docPesoFile, HashMap<String,Double> docPeso) throws FileNotFoundException {
        System.out.println("\nGuardando longitudes de documentos...");
        PrintWriter f = new PrintWriter(docPesoFile);
        f.println(docPeso);
        f.close();
        System.out.println("Longitudes de documentos guardadas en" + docPesoFile);
    }

}
