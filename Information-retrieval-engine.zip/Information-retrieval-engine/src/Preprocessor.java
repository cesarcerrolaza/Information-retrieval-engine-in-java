

public class Preprocessor {

    static FilterManager charFM = new FilterManager();

    static void buildFilter(){
        charFM.addFilter(new Minuscula());
        charFM.addFilter(new SpecialCharacterFilter("[^-\\w]", " "));
        charFM.addFilter(new SpecialCharacterFilter("\\b[0-9]+\\b", " "));
        charFM.addFilter(new SpecialCharacterFilter("-+ | -+", " "));
        charFM.addFilter(new SpecialCharacterFilter(" +", " "));
    }

    public String preprocess(String texto){
        return charFM.execute(texto);
    }

}
